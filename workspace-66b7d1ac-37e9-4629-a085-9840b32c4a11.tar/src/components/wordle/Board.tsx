"use client";

import { cn } from "@/lib/utils";
import type { Cell, GuessResult } from "@/lib/wordle/logic";

interface BoardProps {
  rows: GuessResult[]; // up to 6 committed guesses, each with 5 cells
  currentGuess: string; // the in-progress row
  wordLength: number;
  maxGuesses: number;
  invalidShakeRow: number | null; // index of row that should shake
  revealRow: number | null; // index of row currently revealing (for staggered animation)
}

const STATUS_CLASSES: Record<string, string> = {
  correct: "bg-emerald-500 border-emerald-500 text-white",
  present: "bg-amber-500 border-amber-500 text-white",
  absent: "bg-zinc-500 border-zinc-500 text-white",
  tbd: "bg-transparent border-zinc-400 dark:border-zinc-600 text-foreground",
  empty: "bg-transparent border-zinc-300 dark:border-zinc-700 text-foreground",
};

const FLIP_CLASSES: Record<string, string> = {
  correct: "bg-emerald-500 border-emerald-500 text-white",
  present: "bg-amber-500 border-amber-500 text-white",
  absent: "bg-zinc-600 border-zinc-600 text-white",
  tbd: "bg-transparent border-zinc-400 dark:border-zinc-600 text-foreground",
  empty: "bg-transparent border-zinc-300 dark:border-zinc-700 text-foreground",
};

export function Board({
  rows,
  currentGuess,
  wordLength,
  maxGuesses,
  invalidShakeRow,
  revealRow,
}: BoardProps) {
  const filledRows = rows.length;
  return (
    <div
      className="grid gap-1.5 mx-auto"
      style={{
        gridTemplateRows: `repeat(${maxGuesses}, minmax(0, 1fr))`,
        width: "min(92vw, 22rem)",
      }}
      aria-label="Wordle board"
      role="grid"
    >
      {Array.from({ length: maxGuesses }).map((_, rowIdx) => {
        const committed = rows[rowIdx];
        const isCurrentRow = rowIdx === filledRows;
        const isRevealing = rowIdx === revealRow;
        return (
          <div
            key={rowIdx}
            className={cn(
              "grid gap-1.5",
              invalidShakeRow === rowIdx && "animate-[shake_0.4s_ease-in-out]"
            )}
            style={{
              gridTemplateColumns: `repeat(${wordLength}, minmax(0, 1fr))`,
            }}
            role="row"
          >
            {Array.from({ length: wordLength }).map((_, colIdx) => {
              let cell: Cell;
              if (committed) {
                cell = committed.cells[colIdx];
              } else if (isCurrentRow) {
                const ch = currentGuess[colIdx] ?? "";
                cell = {
                  letter: ch,
                  status: ch ? "tbd" : "empty",
                };
              } else {
                cell = { letter: "", status: "empty" };
              }
              const statusClass = isRevealing
                ? FLIP_CLASSES[cell.status]
                : STATUS_CLASSES[cell.status];
              return (
                <div
                  key={colIdx}
                  role="gridcell"
                  aria-label={cell.letter ? `letter ${cell.letter}` : "empty"}
                  className={cn(
                    "aspect-square flex items-center justify-center rounded-md border-2 text-2xl font-bold uppercase select-none",
                    "transition-colors duration-200",
                    isRevealing &&
                      "animate-[flip_0.5s_ease-in-out_forwards]",
                    isCurrentRow &&
                      cell.status === "tbd" &&
                      "border-zinc-500 dark:border-zinc-400",
                    statusClass
                  )}
                  style={
                    isRevealing
                      ? { animationDelay: `${colIdx * 0.25}s` }
                      : undefined
                  }
                >
                  {cell.letter}
                </div>
              );
            })}
          </div>
        );
      })}
    </div>
  );
}
