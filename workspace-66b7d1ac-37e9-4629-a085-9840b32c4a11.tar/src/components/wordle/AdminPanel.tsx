"use client";

import { useCallback, useEffect, useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { useToast } from "@/hooks/use-toast";
import { formatDateKey, daysBetween } from "@/lib/wordle/logic";
import { Badge } from "@/components/ui/badge";

interface ScheduledWord {
  date: string;
  word: string;
}

function isValidDate(s: string): boolean {
  return /^\d{4}-\d{2}-\d{2}$/.test(s) && !isNaN(Date.parse(`${s}T00:00:00`));
}

function isValidWord(s: string): boolean {
  return /^[a-z]{5}$/.test(s);
}

export function AdminPanel() {
  const { toast } = useToast();
  const [list, setList] = useState<ScheduledWord[]>([]);
  const [loading, setLoading] = useState(true);
  const [date, setDate] = useState<string>(formatDateKey(new Date()));
  const [word, setWord] = useState<string>("");
  const [submitting, setSubmitting] = useState(false);

  const refresh = useCallback(async () => {
    try {
      const res = await fetch("/api/admin/words", { cache: "no-store" });
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const data = await res.json();
      setList(Array.isArray(data.words) ? data.words : []);
    } catch (e) {
      toast({
        title: "Failed to load scheduled words",
        description: e instanceof Error ? e.message : String(e),
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  }, [toast]);

  useEffect(() => {
    refresh();
  }, [refresh]);

  const handleAdd = async () => {
    const d = date.trim();
    const w = word.trim().toLowerCase();
    if (!isValidDate(d)) {
      toast({
        title: "Invalid date",
        description: "Use YYYY-MM-DD format.",
        variant: "destructive",
      });
      return;
    }
    if (!isValidWord(w)) {
      toast({
        title: "Invalid word",
        description: "Word must be exactly 5 lowercase letters.",
        variant: "destructive",
      });
      return;
    }
    setSubmitting(true);
    try {
      const res = await fetch("/api/admin/words", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ date: d, word: w }),
      });
      if (!res.ok) {
        const err = await res.json().catch(() => ({}));
        throw new Error(err.error ?? `HTTP ${res.status}`);
      }
      toast({
        title: "Word saved",
        description: `${w.toUpperCase()} scheduled for ${d}.`,
      });
      setWord("");
      await refresh();
    } catch (e) {
      toast({
        title: "Failed to add word",
        description: e instanceof Error ? e.message : String(e),
        variant: "destructive",
      });
    } finally {
      setSubmitting(false);
    }
  };

  const handleDelete = async (d: string) => {
    try {
      const res = await fetch(`/api/admin/words?date=${encodeURIComponent(d)}`, {
        method: "DELETE",
      });
      if (!res.ok) {
        const err = await res.json().catch(() => ({}));
        throw new Error(err.error ?? `HTTP ${res.status}`);
      }
      toast({
        title: "Removed",
        description: `Word for ${d} removed.`,
      });
      await refresh();
    } catch (e) {
      toast({
        title: "Failed to remove word",
        description: e instanceof Error ? e.message : String(e),
        variant: "destructive",
      });
    }
  };

  const today = formatDateKey(new Date());

  return (
    <div className="space-y-6">
      <section className="rounded-lg border bg-card p-4 sm:p-6">
        <h2 className="text-lg font-semibold mb-1">Schedule a daily word</h2>
        <p className="text-sm text-muted-foreground mb-4">
          Pick a date and enter the 5-letter answer word. Adding a word for a
          date that already exists will overwrite it. Changes are written to the
          static <code className="font-mono text-xs">src/data/dailyWords.json</code>{" "}
          file immediately.
        </p>
        <div className="grid sm:grid-cols-[auto_1fr_auto] gap-3 items-end">
          <div className="grid gap-1.5">
            <Label htmlFor="word-date">Date</Label>
            <Input
              id="word-date"
              type="date"
              value={date}
              onChange={(e) => setDate(e.target.value)}
              className="w-44"
            />
          </div>
          <div className="grid gap-1.5">
            <Label htmlFor="word-text">Answer word</Label>
            <Input
              id="word-text"
              type="text"
              value={word}
              onChange={(e) => setWord(e.target.value)}
              placeholder="e.g. crane"
              maxLength={5}
              className="uppercase tracking-widest"
              onKeyDown={(e) => {
                if (e.key === "Enter") handleAdd();
              }}
            />
          </div>
          <Button onClick={handleAdd} disabled={submitting || !word}>
            {submitting ? "Saving…" : "Add / update"}
          </Button>
        </div>
      </section>

      <section className="rounded-lg border bg-card">
        <div className="p-4 sm:p-6 border-b">
          <h2 className="text-lg font-semibold">
            Scheduled words ({list.length})
          </h2>
          <p className="text-sm text-muted-foreground">
            Past dates are shown dimmed. The next upcoming date is highlighted.
          </p>
        </div>
        <div className="max-h-[24rem] overflow-y-auto">
          <Table>
            <TableHeader className="sticky top-0 bg-card">
              <TableRow>
                <TableHead className="w-32">Date</TableHead>
                <TableHead className="w-20">Day</TableHead>
                <TableHead>Word</TableHead>
                <TableHead className="w-24">Status</TableHead>
                <TableHead className="w-20 text-right">Action</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {loading ? (
                <TableRow>
                  <TableCell colSpan={5} className="text-center text-muted-foreground py-8">
                    Loading…
                  </TableCell>
                </TableRow>
              ) : list.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={5} className="text-center text-muted-foreground py-8">
                    No words scheduled yet. Add one above.
                  </TableCell>
                </TableRow>
              ) : (
                list
                  .slice()
                  .sort((a, b) => b.date.localeCompare(a.date))
                  .map((entry) => {
                    const diff = daysBetween(today, entry.date);
                    const isPast = diff < 0;
                    const isToday = diff === 0;
                    const isNext =
                      diff > 0 &&
                      list
                        .filter((w) => daysBetween(today, w.date) >= 0)
                        .sort((a, b) => a.date.localeCompare(b.date))[0]
                        ?.date === entry.date;
                    return (
                      <TableRow
                        key={entry.date}
                        className={
                          isPast
                            ? "opacity-50"
                            : isToday
                              ? "bg-emerald-50 dark:bg-emerald-950/30"
                              : isNext
                                ? "bg-amber-50 dark:bg-amber-950/20"
                                : ""
                        }
                      >
                        <TableCell className="font-mono">{entry.date}</TableCell>
                        <TableCell className="text-muted-foreground">
                          {new Date(`${entry.date}T00:00:00`).toLocaleDateString(
                            undefined,
                            { weekday: "short" }
                          )}
                        </TableCell>
                        <TableCell className="font-bold uppercase tracking-widest">
                          {entry.word}
                        </TableCell>
                        <TableCell>
                          {isToday ? (
                            <Badge>Today</Badge>
                          ) : isNext ? (
                            <Badge variant="secondary">Next</Badge>
                          ) : isPast ? (
                            <Badge variant="outline">Past</Badge>
                          ) : (
                            <Badge variant="outline">Upcoming</Badge>
                          )}
                        </TableCell>
                        <TableCell className="text-right">
                          <Button
                            variant="ghost"
                            size="sm"
                            className="text-destructive hover:text-destructive"
                            onClick={() => handleDelete(entry.date)}
                          >
                            Remove
                          </Button>
                        </TableCell>
                      </TableRow>
                    );
                  })
              )}
            </TableBody>
          </Table>
        </div>
      </section>
    </div>
  );
}
