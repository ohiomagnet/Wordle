"use client";

import { cn } from "@/lib/utils";
import type { LetterStatus } from "@/lib/wordle/logic";

interface KeyboardProps {
  letterStatuses: Record<string, LetterStatus>;
  onKey: (key: string) => void; // single letter or "ENTER" or "BACKSPACE"
  disabled?: boolean;
}

const ROWS = [
  ["q", "w", "e", "r", "t", "y", "u", "i", "o", "p"],
  ["a", "s", "d", "f", "g", "h", "j", "k", "l"],
  ["ENTER", "z", "x", "c", "v", "b", "n", "m", "BACKSPACE"],
];

const STATUS_BG: Record<LetterStatus, string> = {
  correct: "bg-emerald-500 text-white hover:bg-emerald-500",
  present: "bg-amber-500 text-white hover:bg-amber-500",
  absent:
    "bg-zinc-700 text-zinc-300 hover:bg-zinc-700 dark:bg-zinc-800 dark:text-zinc-500",
  empty: "",
  tbd: "",
};

export function Keyboard({ letterStatuses, onKey, disabled }: KeyboardProps) {
  return (
    <div
      className="flex flex-col items-center gap-1.5 w-full max-w-lg mx-auto px-1 select-none"
      aria-label="On-screen keyboard"
    >
      {ROWS.map((row, rowIdx) => (
        <div
          key={rowIdx}
          className="flex gap-1 sm:gap-1.5 justify-center w-full"
        >
          {row.map((key) => {
            const isSpecial = key === "ENTER" || key === "BACKSPACE";
            const status = letterStatuses[key.toLowerCase()] ?? "empty";
            return (
              <button
                key={key}
                type="button"
                disabled={disabled}
                onClick={() => onKey(key)}
                aria-label={key === "BACKSPACE" ? "Backspace" : key}
                className={cn(
                  "h-12 sm:h-14 rounded-md font-bold uppercase text-sm sm:text-base",
                  "flex items-center justify-center transition-colors",
                  "bg-zinc-200 dark:bg-zinc-700 text-foreground hover:bg-zinc-300 dark:hover:bg-zinc-600",
                  "active:scale-95 disabled:opacity-50 disabled:cursor-not-allowed",
                  isSpecial ? "flex-[1.5] px-2 text-xs sm:text-sm" : "flex-1",
                  STATUS_BG[status]
                )}
              >
                {key === "BACKSPACE" ? "⌫" : key}
              </button>
            );
          })}
        </div>
      ))}
    </div>
  );
}
