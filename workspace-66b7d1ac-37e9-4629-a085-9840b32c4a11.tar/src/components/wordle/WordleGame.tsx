"use client";

import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { Board } from "./Board";
import { Keyboard } from "./Keyboard";
import {
  type Cell,
  type GuessResult,
  type LetterStatus,
  MAX_GUESSES,
  WORD_LENGTH,
  evaluateGuess,
  mergeLetterStatuses,
} from "@/lib/wordle/logic";
import { VALID_GUESSES_SET } from "@/data/validGuesses";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";

interface DailyResponse {
  date: string;
  answer: string;
  wordLength: number;
  maxGuesses: number;
}

interface SavedGame {
  date: string;
  guesses: string[]; // committed guesses, lowercase
  finished: boolean;
  won: boolean;
}

const STORAGE_PREFIX = "wordle:game:";

function loadSaved(date: string): SavedGame | null {
  try {
    const raw = localStorage.getItem(STORAGE_PREFIX + date);
    if (!raw) return null;
    const parsed = JSON.parse(raw) as SavedGame;
    if (parsed.date !== date) return null;
    return parsed;
  } catch {
    return null;
  }
}

function saveGame(state: SavedGame) {
  try {
    localStorage.setItem(STORAGE_PREFIX + state.date, JSON.stringify(state));
  } catch {
    // ignore quota / privacy errors
  }
}

export function WordleGame() {
  const { toast } = useToast();
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [daily, setDaily] = useState<DailyResponse | null>(null);

  const [committed, setCommitted] = useState<GuessResult[]>([]);
  const [committedWords, setCommittedWords] = useState<string[]>([]);
  const [current, setCurrent] = useState("");
  const [finished, setFinished] = useState(false);
  const [won, setWon] = useState(false);
  const [invalidRow, setInvalidRow] = useState<number | null>(null);
  const [revealingRow, setRevealingRow] = useState<number | null>(null);
  const [showResult, setShowResult] = useState(false);
  const [stats, setStats] = useState({ played: 0, won: 0, streak: 0 });

  const answerRef = useRef<string>("");
  const dateRef = useRef<string>("");

  // Fetch today's word on mount.
  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        const res = await fetch("/api/words", { cache: "no-store" });
        if (!res.ok) throw new Error(`HTTP ${res.status}`);
        const data: DailyResponse = await res.json();
        if (cancelled) return;
        setDaily(data);
        answerRef.current = data.answer;
        dateRef.current = data.date;
        // Restore saved progress for this date.
        const saved = loadSaved(data.date);
        if (saved) {
          const restored = saved.guesses.map((g) => evaluateGuess(g, data.answer));
          setCommitted(restored);
          setCommittedWords(saved.guesses);
          setFinished(saved.finished);
          setWon(saved.won);
          if (saved.finished) setShowResult(true);
        }
      } catch (e) {
        if (cancelled) return;
        setError(
          e instanceof Error ? e.message : "Failed to load today's word."
        );
      } finally {
        if (!cancelled) setLoading(false);
      }
    })();
    return () => {
      cancelled = true;
    };
  }, []);

  // Load aggregate stats from localStorage.
  useEffect(() => {
    try {
      const raw = localStorage.getItem("wordle:stats");
      if (raw) setStats(JSON.parse(raw));
    } catch {
      // ignore
    }
  }, []);

  const persistStats = useCallback(
    (nextWon: boolean) => {
      setStats((prev) => {
        const todayKey = dateRef.current;
        const lastWonDate = localStorage.getItem("wordle:lastWonDate");
        let streak = prev.streak;
        if (nextWon) {
          // If user won yesterday (or this is first win), increment; else reset to 1.
          if (lastWonDate === todayKey) {
            // already counted today — keep streak
          } else {
            streak = prev.streak > 0 ? prev.streak + 1 : 1;
          }
          localStorage.setItem("wordle:lastWonDate", todayKey);
        } else {
          streak = 0;
        }
        const next = { played: prev.played + 1, won: prev.won + (nextWon ? 1 : 0), streak };
        localStorage.setItem("wordle:stats", JSON.stringify(next));
        return next;
      });
    },
    []
  );

  const letterStatuses: Record<string, LetterStatus> = useMemo(
    () => mergeLetterStatuses(committed),
    [committed]
  );

  const handleKey = useCallback(
    (key: string) => {
      if (loading || error || finished || revealingRow !== null) return;
      const k = key.toUpperCase();
      if (k === "ENTER") {
        if (current.length !== WORD_LENGTH) {
          toast({
            title: "Not enough letters",
            description: `Each guess must be ${WORD_LENGTH} letters.`,
            variant: "destructive",
          });
          setInvalidRow(committed.length);
          setTimeout(() => setInvalidRow(null), 400);
          return;
        }
        const guess = current.toLowerCase();
        const isAnswer = guess === answerRef.current;
        const inList = VALID_GUESSES_SET.has(guess);
        if (!isAnswer && !inList) {
          toast({
            title: "Not in word list",
            description: `"${guess.toUpperCase()}" isn't in our dictionary.`,
            variant: "destructive",
          });
          setInvalidRow(committed.length);
          setTimeout(() => setInvalidRow(null), 400);
          return;
        }
        // Commit the guess with staggered reveal animation.
        setRevealingRow(committed.length);
        const result = evaluateGuess(guess, answerRef.current);
        const newCommitted = [...committed, result];
        const newWords = [...committedWords, guess];
        const finishedNow = result.correct || newCommitted.length >= MAX_GUESSES;
        const wonNow = result.correct;
        const revealDuration = WORD_LENGTH * 250 + 250; // matches Board flip animation
        setTimeout(() => {
          setCommitted(newCommitted);
          setCommittedWords(newWords);
          setCurrent("");
          setRevealingRow(null);
          if (finishedNow) {
            setFinished(true);
            setWon(wonNow);
            setShowResult(true);
            persistStats(wonNow);
          }
          saveGame({
            date: dateRef.current,
            guesses: newWords,
            finished: finishedNow,
            won: wonNow,
          });
        }, revealDuration);
        return;
      }
      if (k === "BACKSPACE") {
        setCurrent((c) => c.slice(0, -1));
        return;
      }
      if (/^[A-Z]$/.test(k)) {
        if (current.length >= WORD_LENGTH) return;
        setCurrent((c) => c + k.toLowerCase());
      }
    },
    [loading, error, finished, revealingRow, current, committed, committedWords, toast, persistStats]
  );

  // Physical keyboard input.
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.metaKey || e.ctrlKey || e.altKey) return;
      if (e.key === "Enter") {
        e.preventDefault();
        handleKey("ENTER");
      } else if (e.key === "Backspace") {
        e.preventDefault();
        handleKey("BACKSPACE");
      } else if (/^[a-zA-Z]$/.test(e.key)) {
        handleKey(e.key);
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [handleKey]);

  const restart = useCallback(() => {
    setCommitted([]);
    setCommittedWords([]);
    setCurrent("");
    setFinished(false);
    setWon(false);
    setShowResult(false);
    setRevealingRow(null);
    if (dateRef.current) {
      try {
        localStorage.removeItem(STORAGE_PREFIX + dateRef.current);
      } catch {
        // ignore
      }
    }
  }, []);

  const shareText = useMemo(() => {
    if (!daily || committedWords.length === 0) return "";
    const header = `Wordle ${daily.date} ${won ? committedWords.length : "X"}/${MAX_GUESSES}`;
    const grid = committed
      .map((g) =>
        g.cells
          .map((c) => {
            if (c.status === "correct") return "🟩";
            if (c.status === "present") return "🟨";
            return "⬛";
          })
          .join("")
      )
      .join("\n");
    return `${header}\n\n${grid}`;
  }, [committed, committedWords, daily, won]);

  if (loading) {
    return (
      <div className="flex flex-col items-center gap-4 py-12 text-muted-foreground">
        <div className="h-8 w-8 rounded-full border-2 border-foreground/30 border-t-foreground animate-spin" />
        <p>Loading today&apos;s puzzle…</p>
      </div>
    );
  }
  if (error) {
    return (
      <div className="flex flex-col items-center gap-4 py-12 text-center">
        <p className="text-destructive font-medium">Couldn&apos;t load today&apos;s word.</p>
        <p className="text-sm text-muted-foreground">{error}</p>
        <Button variant="outline" onClick={() => window.location.reload()}>
          Retry
        </Button>
      </div>
    );
  }

  const message =
    finished && won
      ? committedWords.length === 1
        ? "Genius!"
        : committedWords.length === 2
          ? "Magnificent!"
          : committedWords.length === 3
            ? "Impressive!"
            : committedWords.length === 4
              ? "Splendid!"
              : committedWords.length === 5
                ? "Great!"
                : "Phew!"
      : finished && !won
        ? `The answer was ${daily?.answer.toUpperCase()}`
        : "";

  return (
    <div className="flex flex-col items-center gap-4 sm:gap-6 w-full">
      {message && (
        <div className="text-center font-bold text-lg sm:text-xl h-6">
          {message}
        </div>
      )}
      <Board
        rows={committed}
        currentGuess={current}
        wordLength={WORD_LENGTH}
        maxGuesses={MAX_GUESSES}
        invalidShakeRow={invalidRow}
        revealRow={revealingRow}
      />
      <Keyboard
        letterStatuses={letterStatuses}
        onKey={handleKey}
        disabled={finished || revealingRow !== null}
      />

      <Dialog open={showResult} onOpenChange={(o) => !o && setShowResult(false)}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="text-center text-2xl">
              {won ? "🎉 You won!" : "Better luck next time"}
            </DialogTitle>
            <DialogDescription className="text-center">
              {won
                ? `Solved in ${committedWords.length}/${MAX_GUESSES} guesses.`
                : "You didn't guess today's word."}
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-3 text-center">
            <div className="rounded-md border p-3">
              <p className="text-xs uppercase tracking-wide text-muted-foreground mb-1">
                Today&apos;s answer
              </p>
              <p className="text-2xl font-bold tracking-widest">
                {daily?.answer.toUpperCase()}
              </p>
            </div>
            <div className="grid grid-cols-3 gap-2 text-sm">
              <div className="rounded-md border p-2">
                <p className="font-bold text-lg">{stats.played}</p>
                <p className="text-muted-foreground">Played</p>
              </div>
              <div className="rounded-md border p-2">
                <p className="font-bold text-lg">
                  {stats.played > 0
                    ? Math.round((stats.won / stats.played) * 100)
                    : 0}
                  %
                </p>
                <p className="text-muted-foreground">Win rate</p>
              </div>
              <div className="rounded-md border p-2">
                <p className="font-bold text-lg">{stats.streak}</p>
                <p className="text-muted-foreground">Streak</p>
              </div>
            </div>
          </div>
          <DialogFooter className="flex-col gap-2 sm:flex-col">
            <Button
              variant="outline"
              className="w-full"
              onClick={() => {
                if (navigator.share && shareText) {
                  navigator.share({ text: shareText }).catch(() => {
                    navigator.clipboard?.writeText(shareText);
                    toast({ title: "Copied result to clipboard" });
                  });
                } else if (shareText) {
                  navigator.clipboard?.writeText(shareText);
                  toast({ title: "Copied result to clipboard" });
                }
              }}
            >
              Share result
            </Button>
            <Button
              variant="secondary"
              className="w-full"
              onClick={restart}
            >
              Reset today&apos;s progress
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
