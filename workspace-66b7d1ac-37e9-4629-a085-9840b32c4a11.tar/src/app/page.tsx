"use client";

import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { WordleGame } from "@/components/wordle/WordleGame";
import { AdminPanel } from "@/components/wordle/AdminPanel";

export default function Home() {
  return (
    <div className="min-h-screen flex flex-col bg-background">
      <header className="border-b">
        <div className="mx-auto max-w-3xl px-4 py-4 flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold tracking-tight">Wordle</h1>
            <p className="text-xs text-muted-foreground">
              Guess the 5-letter word in 6 tries. New word every day.
            </p>
          </div>
          <a
            href="https://github.com"
            target="_blank"
            rel="noopener noreferrer"
            className="text-xs text-muted-foreground hover:text-foreground"
            aria-label="Source"
          >
            Static build
          </a>
        </div>
      </header>

      <main className="flex-1 mx-auto w-full max-w-3xl px-4 py-6">
        <Tabs defaultValue="play" className="w-full">
          <TabsList className="grid w-full max-w-xs mx-auto grid-cols-2">
            <TabsTrigger value="play">Play</TabsTrigger>
            <TabsTrigger value="admin">Manage words</TabsTrigger>
          </TabsList>
          <TabsContent value="play" className="mt-6">
            <WordleGame />
          </TabsContent>
          <TabsContent value="admin" className="mt-6">
            <AdminPanel />
          </TabsContent>
        </Tabs>
      </main>

      <footer className="mt-auto border-t">
        <div className="mx-auto max-w-3xl px-4 py-4 text-center text-xs text-muted-foreground">
          Wordle clone · Daily words stored in a static JSON file ·
          Progress saved locally per device.
        </div>
      </footer>
    </div>
  );
}
