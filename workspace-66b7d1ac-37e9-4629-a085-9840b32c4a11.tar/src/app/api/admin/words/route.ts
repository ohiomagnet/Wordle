import { NextResponse } from "next/server";
import { promises as fs } from "fs";
import path from "path";

interface DailyWordsFile {
  _comment?: string;
  _seedWords?: string[];
  words: Record<string, string>;
}

const FILE_PATH = path.join(process.cwd(), "src", "data", "dailyWords.json");

async function readFile(): Promise<DailyWordsFile> {
  const raw = await fs.readFile(FILE_PATH, "utf-8");
  return JSON.parse(raw) as DailyWordsFile;
}

async function writeFile(data: DailyWordsFile): Promise<void> {
  // 2-space indent matches the original file format for readability.
  await fs.writeFile(FILE_PATH, JSON.stringify(data, null, 2) + "\n", "utf-8");
}

function isValidDate(s: string): boolean {
  return /^\d{4}-\d{2}-\d{2}$/.test(s) && !isNaN(Date.parse(`${s}T00:00:00`));
}

function isValidWord(s: string): boolean {
  return /^[a-z]{5}$/.test(s);
}

// GET /api/admin/words  ->  list all scheduled words (sorted)
export async function GET() {
  const data = await readFile();
  const list = Object.entries(data.words)
    .map(([date, word]) => ({ date, word: word.toLowerCase() }))
    .sort((a, b) => a.date.localeCompare(b.date));
  return NextResponse.json({ words: list });
}

// POST /api/admin/words  ->  add or update a (date, word) entry
//   body: { date: "2026-11-04", word: "lemon" }
export async function POST(req: Request) {
  let body: { date?: string; word?: string };
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: "Invalid JSON body." }, { status: 400 });
  }
  const date = (body.date ?? "").trim();
  const word = (body.word ?? "").trim().toLowerCase();
  if (!isValidDate(date)) {
    return NextResponse.json(
      { error: "Date must be in YYYY-MM-DD format." },
      { status: 400 }
    );
  }
  if (!isValidWord(word)) {
    return NextResponse.json(
      { error: "Word must be exactly 5 lowercase letters (a-z)." },
      { status: 400 }
    );
  }
  const data = await readFile();
  data.words[date] = word;
  await writeFile(data);
  return NextResponse.json({ ok: true, date, word });
}

// DELETE /api/admin/words?date=2026-11-04  ->  remove an entry
export async function DELETE(req: Request) {
  const url = new URL(req.url);
  const date = url.searchParams.get("date") ?? "";
  if (!isValidDate(date)) {
    return NextResponse.json(
      { error: "Date must be in YYYY-MM-DD format." },
      { status: 400 }
    );
  }
  const data = await readFile();
  if (!(date in data.words)) {
    return NextResponse.json(
      { error: `No word scheduled for ${date}.` },
      { status: 404 }
    );
  }
  delete data.words[date];
  await writeFile(data);
  return NextResponse.json({ ok: true, date });
}
