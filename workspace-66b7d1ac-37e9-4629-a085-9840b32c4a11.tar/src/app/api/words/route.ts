import { NextResponse } from "next/server";
import { promises as fs } from "fs";
import path from "path";
import { formatDateKey } from "@/lib/wordle/logic";

interface DailyWordsFile {
  _comment?: string;
  _seedWords?: string[];
  words: Record<string, string>;
}

const FILE_PATH = path.join(process.cwd(), "src", "data", "dailyWords.json");

async function readFile(): Promise<DailyWordsFile> {
  const raw = await fs.readFile(FILE_PATH, "utf-8");
  return JSON.parse(raw) as DailyWordsFile;
}

// GET /api/words  ->  returns today's answer word + upcoming scheduled words
export async function GET() {
  const data = await readFile();
  const today = formatDateKey(new Date());
  const seedWords = data._seedWords ?? [];
  const fallback =
    seedWords[hashString(today) % Math.max(seedWords.length, 1)] ?? "crane";
  const answer = (data.words[today] ?? fallback).toLowerCase();

  return NextResponse.json({
    date: today,
    answer,
    wordLength: 5,
    maxGuesses: 6,
    upcoming: Object.entries(data.words)
      .filter(([k]) => k >= today)
      .sort(([a], [b]) => a.localeCompare(b))
      .slice(0, 14)
      .map(([date, word]) => ({ date, word: word.toLowerCase() })),
  });
}

function hashString(s: string): number {
  let h = 0;
  for (let i = 0; i < s.length; i++) {
    h = (h * 31 + s.charCodeAt(i)) >>> 0;
  }
  return h;
}
