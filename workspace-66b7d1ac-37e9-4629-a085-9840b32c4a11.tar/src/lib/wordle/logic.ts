// Wordle game logic — pure functions, no React.
// All words are lowercase 5-letter strings.

export const WORD_LENGTH = 5;
export const MAX_GUESSES = 6;

export type LetterStatus = "correct" | "present" | "absent" | "empty" | "tbd";

export interface Cell {
  letter: string;
  status: LetterStatus;
}

export interface GuessResult {
  cells: Cell[]; // length 5
  correct: boolean;
}

/**
 * Evaluate a guess against the answer using classic Wordle rules.
 * - correct: letter in the right position (green)
 * - present: letter in the word but wrong position (yellow)
 * - absent:  letter not in the word (gray)
 * Handles duplicate letters correctly (two-pass algorithm).
 */
export function evaluateGuess(guess: string, answer: string): GuessResult {
  const g = guess.toLowerCase();
  const a = answer.toLowerCase();
  const cells: Cell[] = Array.from({ length: WORD_LENGTH }, () => ({
    letter: "",
    status: "absent" as LetterStatus,
  }));

  // First pass: mark correct (green) letters.
  const answerLetterCount: Record<string, number> = {};
  for (let i = 0; i < WORD_LENGTH; i++) {
    const ch = a[i];
    answerLetterCount[ch] = (answerLetterCount[ch] ?? 0) + 1;
  }
  for (let i = 0; i < WORD_LENGTH; i++) {
    const ch = g[i];
    cells[i].letter = ch;
    if (ch === a[i]) {
      cells[i].status = "correct";
      answerLetterCount[ch] -= 1;
    }
  }
  // Second pass: mark present (yellow) letters.
  for (let i = 0; i < WORD_LENGTH; i++) {
    if (cells[i].status === "correct") continue;
    const ch = g[i];
    if ((answerLetterCount[ch] ?? 0) > 0) {
      cells[i].status = "present";
      answerLetterCount[ch] -= 1;
    } else {
      cells[i].status = "absent";
    }
  }
  return { cells, correct: g === a };
}

/**
 * Merge per-letter statuses across multiple guesses for keyboard coloring.
 * Priority: correct > present > absent.
 */
export function mergeLetterStatuses(
  guesses: GuessResult[]
): Record<string, LetterStatus> {
  const priority: Record<LetterStatus, number> = {
    correct: 3,
    present: 2,
    absent: 1,
    empty: 0,
    tbd: 0,
  };
  const result: Record<string, LetterStatus> = {};
  for (const g of guesses) {
    for (const cell of g.cells) {
      const prev = result[cell.letter];
      if (!prev || priority[cell.status] > priority[prev]) {
        result[cell.letter] = cell.status;
      }
    }
  }
  return result;
}

/**
 * Returns YYYY-MM-DD in the user's local timezone for a given Date.
 */
export function formatDateKey(date: Date): string {
  const y = date.getFullYear();
  const m = String(date.getMonth() + 1).padStart(2, "0");
  const d = String(date.getDate()).padStart(2, "0");
  return `${y}-${m}-${d}`;
}

/**
 * Given a date-keyed word map, find today's answer word.
 * Falls back to deterministic seed-based selection if today has no entry.
 */
export function getAnswerForDate(
  dateKey: string,
  words: Record<string, string>,
  seedWords: string[]
): string {
  if (words[dateKey]) return words[dateKey].toLowerCase();
  // Deterministic fallback: hash the date to pick a seed word.
  let hash = 0;
  for (let i = 0; i < dateKey.length; i++) {
    hash = (hash * 31 + dateKey.charCodeAt(i)) >>> 0;
  }
  return seedWords[hash % seedWords.length].toLowerCase();
}

/**
 * Number of days between two date keys (YYYY-MM-DD).
 * Positive means `to` is after `from`.
 */
export function daysBetween(fromKey: string, toKey: string): number {
  const a = new Date(`${fromKey}T00:00:00`);
  const b = new Date(`${toKey}T00:00:00`);
  return Math.round((b.getTime() - a.getTime()) / (24 * 60 * 60 * 1000));
}
